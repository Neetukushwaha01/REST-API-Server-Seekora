from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.db.models import Q
from sklearn.decomposition import PCA

from .models import User
from .serializers import UserSerializer
from sklearn.feature_extraction.text import TfidfVectorizer


# POST & GET Users in One Class
class UserView( APIView ):
    """Handles Adding and Retrieving Users"""

    def post(self, request):
        serializer = UserSerializer( data=request.data )
        if serializer.is_valid():
            serializer.save()
            return Response( serializer.data, status=status.HTTP_201_CREATED )
        return Response( serializer.errors, status=status.HTTP_400_BAD_REQUEST )

    def get(self, request):
        users = User.objects.all()
        serializer = UserSerializer( users, many=True )
        return Response( serializer.data )


# GET: Filter Users
class UserFilterView( APIView ):
    """Filters users based on name or email"""

    def get(self, request):
        query = request.GET.get( 'query', '' )
        if query:
            users = User.objects.filter( Q( name__icontains=query ) | Q( email__icontains=query ) )
            serializer = UserSerializer( users, many=True )
            return Response( serializer.data )
        return Response( {"message": "Please provide a query parameter"}, status=status.HTTP_400_BAD_REQUEST )

class StringVectorizeView(APIView):
    def post(self, request):
        text = request.data.get('text', '').strip()
        if not text:
            return Response({"error": "No text provided"}, status=status.HTTP_400_BAD_REQUEST)

        dummy_sentences = ["machine learning is amazing", "deep learning with Python", "AI is transforming the world"]
        corpus = dummy_sentences + [text]

        vectorizer = TfidfVectorizer()
        tfidf_matrix = vectorizer.fit_transform(corpus).toarray()

        input_vector = tfidf_matrix[-1]

        n_features = input_vector.shape[0]
        if n_features > 4:
            pca = PCA(n_components=4)
            transformed_vector = pca.fit_transform(tfidf_matrix)[-1].tolist()
        else:
            transformed_vector = input_vector.tolist()


        vector = [round(abs(num), 3) for num in transformed_vector]

        return Response({"vector": vector}, status=status.HTTP_200_OK)
