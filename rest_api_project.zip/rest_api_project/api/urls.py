from django.urls import path
from .views import UserView, UserFilterView, StringVectorizeView

urlpatterns = [
    path('user/', UserView.as_view(), name='user'),  # POST & GET
    path('filter/', UserFilterView.as_view(), name='filter_users'),  # GET Filtered Users
    path('vectorize/', StringVectorizeView.as_view(), name='vectorize_string'),  # POST String Vectorization
]
