from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import User  # Import your User model

# Register User model in Django Admin
@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'email')  # Fields to display in admin panel
    search_fields = ('name', 'email')  # Enable search on name & email
